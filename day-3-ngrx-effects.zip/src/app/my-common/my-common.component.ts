import { Component } from '@angular/core';

@Component({
  selector: 'app-my-common',
  standalone: true,
  imports: [],
  templateUrl: './my-common.component.html',
  styleUrl: './my-common.component.css'
})
export class MyCommonComponent {

}
