export class Utils{

  doSomething(){

  }

}
