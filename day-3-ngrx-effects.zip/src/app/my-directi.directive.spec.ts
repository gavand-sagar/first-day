import { MyDirectiDirective } from './orders/my-directi.directive';

describe('MyDirectiDirective', () => {
  it('should create an instance', () => {
    const directive = new MyDirectiDirective();
    expect(directive).toBeTruthy();
  });
});
