import { Cart } from "./data/cart/cart.reducers";

export interface AppRootState {
  count: number,
  cart: Cart
}
