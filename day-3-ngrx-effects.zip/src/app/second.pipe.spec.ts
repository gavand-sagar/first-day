import { SecondPipe } from './second.pipe';

describe('SecondPipe', () => {
  it('create an instance', () => {
    const pipe = new SecondPipe();
    expect(pipe).toBeTruthy();
  });
});
